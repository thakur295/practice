import os
import re
import random
import hashlib
import hmac
from string import letters

import webapp2
import jinja2

from google.appengine.ext import db

template_dir = os.path.join(os.path.dirname(__file__), 'templates')
jinja_env = jinja2.Environment(loader = jinja2.FileSystemLoader(template_dir),
                               autoescape = True)

#form validation functions
USER_name = re.compile(r"^[a-zA-Z0-9_-]{3,20}$")
USER_password = re.compile(r"^.{3,20}$")
USER_email = re.compile(r"^[\S]+@[\S]+.[\S]+$")

def valid_username(username):
    return USER_name.match(username)

def valid_password(password):
    return USER_password.match(password)

def match_pass(password , v_password ):
    if password == v_password :
        return True
    else:
        return False

def valid_email(email):
    return USER_email.match(email)

#funtions to set secure cookie value
secret = "RAW_is_great"

def make_secure_val(val):
    return '%s|%s' % (val, hmac.new(secret, val).hexdigest())

def check_secure_val(secure_val):
    val = secure_val.split('|')[0]
    if secure_val == make_secure_val(val):
        return val

#fuctions to secure passwords
def make_salt(length = 5):
    return ''.join(random.choice(letters) for x in xrange(length))

def make_secure_pass(name, pw, salt = None):
    if not salt:
        salt = make_salt()
    h = hashlib.sha256(name + pw + salt).hexdigest()
    return '%s,%s' % (salt, h)

def valid_pass(name, password, h):
    salt = h.split(',')[0]
    return h == make_secure_pass(name, password, salt)

def check_cookie():
    name_val = self.request.cookies.get('name_id')
    if name_val:
        return check_secure_val(name_val)

def count_likes(blog_value):
    return db.GqlQuery('SELECT COUNT(*) FROM Likes Where blog=' + (blog_value))

def count_likes(blog_value):
    return db.GqlQuery('SELECT COUNT(*) FROM dislikes Where blog=' + (blog_value))


#blogs databse
class Blogs(db.Model):
    user = db.StringProperty(required = True)
    title = db.StringProperty(required = True)
    blog = db.TextProperty(required = True)
    created = db.DateTimeProperty(auto_now_add = True)
    last_modified = db.DateTimeProperty(auto_now = True)

#user database
class User_info(db.Model):
    name = db.StringProperty(required = True)
    password = db.StringProperty(required = True)
    email = db.StringProperty()

#likes database
class Likes(db.Model):
    blog = db.StringProperty(required = True)
    user = db.StringProperty(required = True)

#Dislikes database
class Dislikes(db.Model):
    blog = db.StringProperty(required = True)
    user = db.StringProperty(required = True)

#Comments database
class Comments(db.Model):
    blog = db.StringProperty(required = True)
    user = db.StringProperty(required = True)
    comments = db.TextProperty(required = True)
    commented = db.DateTimeProperty(auto_now_add = True)



class Handler(webapp2.RequestHandler):
    def write(self, *a, **kw):
        self.response.out.write(*a, **kw)

    def render_str(self, template, **params):
        t = jinja_env.get_template(template)
        return t.render(params)

    def render(self, template, **kw):
        self.write(self.render_str(template, **kw))

class BLogs(Handler):
    def get(self):
        blogs = db.GqlQuery("SELECT * FROM Blogs ORDER BY created DESC limit 10")
        self.render("blogs.html", blogs = blogs)



class AddBlogPage(Handler):
    def render_front(self, title = "", blog = "", error=""):
        self.render("newblog.html", title = title,
                    blog = blog, error = error)

    def get(self):
        self.render_front()

    def post(self):
        title = self.request.get("title")
        blog = self.request.get("blog")

        if title and blog:
            name_val = self.request.cookies.get('name_id')
            if name_val:
                check_name = check_secure_val(name_val)
                if check_name:
                    user = User_info.get_by_id(int(check_name)).name
                    b = Blogs(user = user, title = title, blog = blog)
                    b.put()
                    self.redirect("/blogs/%s" % str(b.key().id()))
                else:
                    self.redirect('/')
            else:
                self.redirect('/')
        else:
            error = "we need both fields"
            self.render_front(title, blog, error)




#for login_page
class MainHandler(Handler):
    def get(self):
        self.render('login.html')

    def post(self):
        name = self.request.get("username")
        password = self.request.get("pass")

        user = User_info.all().filter('name =', name).get()
        if user and valid_pass(name, password, user.password):
            new_cookie_val = make_secure_val(str(user.key().id()))
            self.response.headers.add_header('Set-Cookie', "name_id=%s; Path=/" % new_cookie_val)
            self.redirect('/blogs')
        else:
            self.render("login.html", error = "Invalid Login")

#for signup_page
class SignupHandler(Handler):
    def get(self):
        self.render('signup.html')

    def post(self):
        user_username = self.request.get("username")
        user_password = self.request.get("password")
        user_re_password = self.request.get("verify")
        user_email = self.request.get("email")

        verify_user_username = valid_username(user_username)
        verify_user_password = valid_password(user_password)
        match_password = match_pass(user_password,user_re_password)
        verify_email = valid_email(user_email)

        error_username = ""
        error_password = ""
        error_verify = ""
        error_email = ""
        flag = True

        if not verify_user_username:
            error_username = "Not valid username"
            flag = False
        if not verify_user_password:
            error_password = "Not valid password"
            flag = False
        if not match_password and user_password:
            error_verify = "password not verified"
            flag = False
        if user_email and not verify_email:
            error_email = "Not a valid email"
            flag = False

        if flag and User_info.all().filter('name =', user_username).get():
            self.render("signup.html", invalid_user = "%s already exist" %user_username)
        elif flag:
            a = User_info(name = user_username, password = make_secure_pass(user_username, user_password),
                          email = user_email)
            a.put()
            new_cookie_val = make_secure_val(str(a.key().id()))
            self.response.headers.add_header('Set-Cookie', "name_id=%s; Path=/" % new_cookie_val)
            self.redirect('/Welcome')
        else:
            self.render("signup.html", invalid_user = error_username,
                        invalid_pass = error_password, not_verified = error_verify,
                        invalid_email = error_email, user = user_username,
                        passW = user_password, re = user_re_password, mail = user_email)

#logout class
class LogoutHandler(Handler):
    def get(self):
        self.response.headers.add_header('Set-Cookie', "name_id=; Path=/")
        self.redirect('/')

#Welcome class
class WelcomeHandler(Handler):
    def get(self):
        cookie = check_cookie()
        if cookie:
            self.render("Welcome.html", name = User_info.get_by_id(int(cookie)).name)
        else:
            self.redirect("/signup")

#class for operation on blog
class OperationHandler(Handler):
    def get(self,post_key):
        key = db.Key.from_path('Blogs', int(post_key))
        blog = db.get(key)

        '''if not blog:
            self.error(404)
            return'''
        likes = Like.count_likes(post_key)
        dislikes = Dislike.count_dislikes(post_key)
        self.render("/blogpage.html", blog = post, likes = likes, dislikes = dislikes)

    def post(self):
        like_post_id = self.request.get("like")
        dislike_post_id = self.request.get("dislike")
        error = ""

        if like_post_id:
            blog_value = self.request.get("like")
            user_id = check_cookie()
            check_user = db.GqlQuery('SELECT * FROM Blogs WHERE title =' + Blogs.get_by_id(int(blog_value)).name + ' and ' + 'user=' + user_id)
            if check_user:
                u  = db.GqlQuery('SELECT * FROM Likes WHERE blog=' + blog_value + ' and ' + 'user=' + user_id)
                if not u:
                    l = Likes(blog = blog_value, user = user_id)
                    l.put()
                else:
                    error = "You Cann't like again"

            else:
                error = "You Cann't like your own post"

            self.get.render('/blogpage', error = error, likes = count_likes(blog_value))

        else:
            blog_value = self.request.get("dislike")
            user_id = check_cookie()
            check_user = db.GqlQuery('SELECT * FROM Blogs WHERE title =' + Blogs.get_by_id(int(blog_value)).name + ' and ' + 'user=' + user_id)
            if check_user:
                u  = db.GqlQuery('SELECT * FROM Likes WHERE blog=' + blog_value + ' and ' + 'user=' + user_id)
                if not u:
                    ds = disikes(blog = blog_value, user = user_id)
                    ds.put()
                else:
                    error = "You Cann't dislike it again"

            else:
                error = "You Cann,t dislike your own post"

            self.get.render('/blogpage', error = error, disikes = count_dislikes(blog_value))



# class for addedblog
class Added_Blog(Handler):
    def get(self, key):
        blog = Blogs.get_by_id(int(key))
        self.render("permalink.html", blog = blog)

app = webapp2.WSGIApplication([
    ('/', MainHandler),
    ('/signup', SignupHandler),
    ('/logout', LogoutHandler),
    ('/blogs', BLogs),
    ('/blogs/addblog', AddBlogPage),
    ('/Welcome', WelcomeHandler),
    ('/blogs/([0-9]+)', Added_Blog),
    ('/blogpage/([0-9]+)', OperationHandler)
], debug=True)
